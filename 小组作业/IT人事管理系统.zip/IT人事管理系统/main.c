#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
#include"stuff.h"
stuff* head = NULL;

int main() {
    int userChoice;

    while (1) {
        userChoice = menu();
        switch (userChoice) {
        case 1: queryStaff(head); break;  // ���ScanStuffҲ��Ҫ�޸�
        case 2: ScanStuff(&head); break;
        case 3: deleteEmployee(head); break;
        case 4:modifyEmp(head) ; break;
        case 5: statisticsEmployee(head); break;
        case 6: sortEmployees(&head); break;  // ����head�ĵ�ַ
        case 7: showEmployeeNamesAndIds(head); break;
        case 0:
            printf("�ټ���\n");
            while (head != NULL) {
                stuff* temp = head;
                head = head->next;
                free(temp);
            }
            exit(0);
            break;
        default: printf("��Чѡ�����������룡\n");
        }
    }
    return 0;
}