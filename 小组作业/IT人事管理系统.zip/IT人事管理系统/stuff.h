#ifndef STUFF_H
#define STUFF_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef struct birthday {
    int year;
    int month;
    int date;
} birthday;

typedef struct stuff_information_character {
    char name[50];//����
    char sex[3];//�Ա�
    long long idCard;//����֤��
    birthday bornDay;//��������
    long long phoneNumber;//�ֻ���
    char nationality[20];//����
    char nation[20];//����
} stuff_information_character;

typedef struct stuff {
    stuff_information_character Stuff;
    char id_c;//���š�����ĸ
    int id_n;//���š�������
    char position[20];//ְλ
    int ward_month;//��н
    int age;//����
    struct stuff* next;
} stuff;

extern stuff* head;

// �޸ĺ�������������һ����
void deleteEmployee(stuff* head);
void deleteEmployeeByFullId(char id_c, int id_n);
void deleteEmployeeByName(char* name);
void deleteEmployeeNode(stuff* prev, stuff* current);
void sortEmployees(stuff** head);  // ��Ϊ����ָ��
void bubbleSort(stuff** arr, int length, int (*compare)(stuff*, stuff*), int order);
int compareByEmployeeId(stuff* a, stuff* b);
int compareByName(stuff* a, stuff* b);
int compareBySalary(stuff* a, stuff* b);
int compareByAge(stuff* a, stuff* b);
int compareByWorkAge(stuff* a, stuff* b);
void ScanStuff(stuff** head);
stuff* CreatStuff(stuff* head, char name[], char sex[], long long idCard, int year,
    int month, int date, long long phoneNumber, char nationality[],
    char nation[], char id_c, int id_n, char position[], int ward_month, int age);
void modifyEmp(stuff* head);
stuff* findEmp(stuff* head, char id_c, int id_n);
void queryStaff(stuff* head);
void statisticsEmployee(stuff* head);
void countTotalEmp();
void countSalaryRange();
void countWorkAge();
void calcAvgSalary();
void showEmployeeNamesAndIds(stuff* head);  // ȷ�����������ȷ
int menu();
int check(char sex[], long long idCard, int month, int date, long long phoneNumber, int age);

#endif
